/* Write a C program to IMPLEMENT BREADTH FIRST SEARCH TRAVERSAL ON A GRAPH 
WE ARE USING ADJACENCY MATRIX.
OPERATIONS:
PERFORM READ GRAPH ,PRINT GRAPH AND THEN BFS. 
DEFINE MAX AS 15
READ NUMBER OF VERTICES IN "n" in first line.
from second line the adjacency matrix values 0 or 1 depending on edge exists or not.
Next read the start vertex from which to u begin BFS.
Example1:
Test case1:
input=
3
0
1
0
1
0
0
0
0
0
1
output=
VERTEX 1 0  1  0  
VERTEX 2 1  0  0  
VERTEX 3 0  0  0  
The BFS Traversal of Graph is :
1 ,2 ,
The vertex 3 is not reachable from 1
Example2:
Test case2:
input=
3
0
0
0
0
0
0
0
0
0
2
output=
VERTEX 1 0  0  0  
VERTEX 2 0  0  0  
VERTEX 3 0  0  0  
The BFS Traversal of Graph is :
2 ,
The vertex 1 is not reachable from 2
The vertex 3 is not reachable from 2

 start writing from here....! */
#include<stdio.h>
#define MAX 15
void getgraph();
void printgraph(); 
void BFS(int v);
int dequeue();
void enqueue(int v);
int Visited[MAX]={0};
int G[MAX][MAX];
int Q[MAX];
int n,r=-1,f=-1;
int main()
{
    int s,i;
    scanf("%d",&n);
    getgraph();
    printgraph();
    if(n==0)
    printf("\nGraph Empty - No BFS");
    else
    {
    scanf("%d",&s);
    printf("\nThe BFS Traversal of Graph is :\n");    
     BFS(s);
     for(i=1;i<=n;i++) 
     {
       if(Visited[i]==0) 
       //BFS(i);
       printf("\nThe vertex %d is not reachable from %d",i,s);
     } 
    }
}
void BFS(int v)
{
int i,res;
Visited[v]=1;
enqueue(v);
while(f!=-1) 
{
   res=dequeue();
   printf("%d ,",res); 
   for(i=1;i<=n;i++)
   {
       if(G[res][i]==1&&Visited[i]==0) 
       {
           enqueue(i);
           Visited[i]=1;
       }
   }
 }
}
int dequeue()
{
    int ver;
    if(f==-1)
    {
        printf("\n Q Underflow");
        return -1;
    }
    ver=Q[f];
    if(r==f)
    r=f=-1;
    else
    f++;
    return(ver);
}
void enqueue(int v)
{
  if(r==MAX-1)
    {
        printf("\n Q Overflow");
        return;
    }  
    Q[++r]=v;
    if(r==0)
    f=0;
}

void getgraph()
{
  int i,j;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            scanf("%d",&G[i][j]);
        }
    }  
}
void printgraph()
{
    int i,j;
    for(i=1;i<=n;i++)
    {
        printf("\nVERTEX %d ",i);
        for(j=1;j<=n;j++)
        {
            printf("%d  ",G[i][j]);
        }
    }
}